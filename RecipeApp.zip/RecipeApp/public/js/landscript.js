document.addEventListener("DOMContentLoaded", function () {
    const subscribeForm = document.querySelector(".newsletter form");
    const subscribeButton = document.querySelector(".newsletter button");

    if (subscribeForm && subscribeButton) {
        subscribeForm.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent form from reloading the page

            const emailInput = document.querySelector(".newsletter input");
            if (emailInput.value.trim() === "") {
                alert("Please enter a valid email address.");
                return;
            }

            // Display success message
            const successMessage = document.createElement("p");
            successMessage.textContent = "Successfully Subscribed!";
            successMessage.style.color = "#28a745";
            successMessage.style.fontWeight = "bold";
            successMessage.style.marginTop = "10px";

            subscribeForm.appendChild(successMessage);

            // Clear input field
            emailInput.value = "";

            // Remove success message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
        });
    }
});
