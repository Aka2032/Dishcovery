require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const axios = require('axios');

const authRoutes = require('./routes/auth');
const recipeRoutes = require('./routes/recipe');
const Recipe = require('./models/Recipe'); // ✅ Use the imported model

const app = express();
const PORT = process.env.PORT || 5000;

// Validate environment variables
if (!process.env.MONGO_URI || !process.env.SPOONACULAR_API_KEY) {
    throw new Error("Missing required environment variables! Check .env file.");
}

const API_KEY = process.env.SPOONACULAR_API_KEY;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.json());

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
    .then(() => console.log('✅ MongoDB connected'))
    .catch(err => console.error('❌ MongoDB Connection Error:', err));

// Get recipes based on ingredients, diet, and cuisine
app.get('/recipes', async (req, res) => {
    const { ingredients, diet, cuisine } = req.query;

    if (!ingredients) {
        return res.status(400).json({ error: 'Ingredients are required' });
    }

    try {
        const response = await axios.get(`https://api.spoonacular.com/recipes/findByIngredients`, {
            params: {
                ingredients,
                diet: diet !== 'none' ? diet : '',
                cuisine: cuisine !== 'any' ? cuisine : '',
                number: 10,
                apiKey: API_KEY
            }
        });

        const recipes = response.data.map(recipe => ({
            title: recipe.title,
            readyInMinutes: recipe.readyInMinutes,
            instructions: recipe.instructions || "No instructions available",
            nutrition: {
                calories: recipe.nutrition?.calories || 'N/A' // ✅ Fix potential undefined value
            },
            id: recipe.id
        }));

        res.json({ recipes });
    } catch (err) {
        console.error('❌ Error fetching recipes:', err);
        res.status(500).json({ error: 'Error fetching recipes from the API' });
    }
});

// Save recipe to MongoDB
app.post('/save-recipe/:id', async (req, res) => {
    try {
        const recipeId = req.params.id;

        const response = await axios.get(`https://api.spoonacular.com/recipes/${recipeId}/information`, {
            params: { apiKey: API_KEY }
        });

        const savedRecipe = new Recipe({
            title: response.data.title,
            recipeId: response.data.id,
            readyInMinutes: response.data.readyInMinutes,
            instructions: response.data.instructions,
            calories: response.data.nutrition?.calories || 'N/A' // ✅ Fix undefined calories
        });

        await savedRecipe.save();
        res.json({ message: '✅ Recipe saved successfully!' });
    } catch (err) {
        console.error('❌ Error saving recipe:', err);
        res.status(500).json({ error: 'Error saving recipe' });
    }
});

// Routes
app.use("/auth", authRoutes);
app.use('/user-recipes', recipeRoutes); // ✅ Avoid conflict with `/recipes`

// Start Server
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
