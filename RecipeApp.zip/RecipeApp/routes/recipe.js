const express = require('express');
const Recipe = require('../models/Recipe');
const jwt = require('jsonwebtoken');

const router = express.Router();

// ✅ Middleware for authentication
const verifyUser = (req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) return res.status(403).json({ message: 'Unauthorized' });

    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) return res.status(403).json({ message: 'Invalid token' });
        req.userId = decoded.id;
        next();
    });
};

// ✅ Create Recipe
router.post('/', verifyUser, async (req, res) => {
    try {
        const { title, ingredients, instructions, calories } = req.body;
        const newRecipe = new Recipe({ title, ingredients, instructions, calories });

        await newRecipe.save();
        res.json({ message: 'Recipe added successfully', recipe: newRecipe });
    } catch (err) {
        console.error('Error adding recipe:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ✅ Get All Recipes
router.get('/', verifyUser, async (req, res) => {
    try {
        const recipes = await Recipe.find();
        res.json({ recipes });
    } catch (err) {
        console.error('Error fetching recipes:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ✅ Update Recipe
router.put('/:id', verifyUser, async (req, res) => {
    try {
        const updatedRecipe = await Recipe.findByIdAndUpdate(req.params.id, req.body, { new: true });

        if (!updatedRecipe) {
            return res.status(404).json({ error: 'Recipe not found' });
        }

        res.json({ message: 'Recipe updated successfully', updatedRecipe });
    } catch (err) {
        console.error('Error updating recipe:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ✅ Delete Recipe
router.delete('/:id', verifyUser, async (req, res) => {
    try {
        const deletedRecipe = await Recipe.findByIdAndDelete(req.params.id);
        if (!deletedRecipe) {
            return res.status(404).json({ error: 'Recipe not found' });
        }

        res.json({ message: 'Recipe deleted successfully' });
    } catch (err) {
        console.error('Error deleting recipe:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
