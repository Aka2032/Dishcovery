const express = require("express");
const router = express.Router();
const User = require("../models/User"); // Import User model
const bcrypt = require("bcryptjs"); // ✅ Import bcrypt
const jwt = require("jsonwebtoken"); // ✅ Import JWT
const SECRET_KEY = "your_secret_key"; // Replace with a secure key

// Login Route
router.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body;

        // Validate required fields
        if (!email || !password) {
            return res.status(400).json({ error: "Email and password are required." });
        }

        // Check if user exists
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(401).json({ error: "Invalid credentials." });
        }

        // Compare passwords
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ error: "Invalid credentials." });
        }

        // Generate JWT Token
        const token = jwt.sign({ id: user._id }, SECRET_KEY, { expiresIn: "1h" });

        res.json({
            message: "✅ Login successful!",
            username: user.username,
            token
        });

    } catch (error) {
        console.error("❌ Error in login:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

module.exports = router;
